## Tela do Plantão

Sistema de Plantão Médico, inicialmente locado.

## Funções
- Cadastro de unidade de saúde
- Cadastro de médico especialista, com valor do plantão
- Cadastro de escala dos médicos
- Validação de entrada e saída dos médicos no plantão
- Relatórios diversos 

>[!WARNING]
 1. Registrar em BD próprio as infromações do sistema via API
 1. Extrair especialistas cadastrados para arquivo .csv que será importado no Rocket.Chat [[Criar um omnichannel]]
 1. Sistema precisa ser totalmente desenvolvido




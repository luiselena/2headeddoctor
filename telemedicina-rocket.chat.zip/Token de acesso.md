Grave o seu código com cuidado, pois não poderá mais visualizá-lo depois.  
token: **hyrMUGdSUhOuwTjQZNVCBzoy9TMhI_ZYXnUjJr2hviG**  
O seu ID de usuário: **wrJfvQctwb6s7tMnD**

Department List
curl -H "X-Auth-Token: hyrMUGdSUhOuwTjQZNVCBzoy9TMhI_ZYXnUjJr2hviG" -H "X-User-Id: wrJfvQctwb6s7tMnD" https://rocket.2headed.xyz/api/v1/livechat/department

curl -H "Content-type:application/json" \  
      https:/rocket.2headed.xyz/api/v1/login \  
      -d '{ "user": "luiselena", "password": "lulues" }'
	  

User List
curl -H "X-Auth-Token: hyrMUGdSUhOuwTjQZNVCBzoy9TMhI_ZYXnUjJr2hviG" -H "X-User-Id: wrJfvQctwb6s7tMnD" https://rocket.2headed.xyz/api/v1/users.list

## Rocked.chat

Ferramenta gratuita que tem funcionalidades de callcenter.

Deverá ter filas pré-configuradas com as especialidades;

Cada médico especialista deverá estar cadastrado no Rocket.chat e associado a uma fila;

A disponibilidade do médico especialista deverá vir do sistema de Plantão Médico [[sistema de plantão]] por meio de [[APIs]].

As APis do Rocket.chat deverão ser integradas ao sistema principal para que o médico contratante não mde de interface.

Os médicos especialistas irão usar o sistema de plantão para fazer checin e checkou em seus plantões e o Rocket.chat para interagir com os médicos contratantes.


Deve ser usado o modelo de OMNICHANNEL do Rocket.Chat 
- Criar departamentos
- Criar agentes
- Associar agentes a departamentos

https://docs.rocket.chat/guides/omnichannel


Docker-compose para instalar o Rocket.chat
https://gist.github.com/caiqueportela/6272158071b4f22a0cfd0e2726c3d858
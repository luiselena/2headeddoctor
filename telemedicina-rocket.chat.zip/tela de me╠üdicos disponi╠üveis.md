## Tela dos médicos disponíveis

Sistema deve exibir relação dos especialistas que estão em plantão, cujas especiaidades fazem parte do contratante.

Estes especialistas são:

1) Verificar no pacote do contratante quais especialidades são ativas
2) Buscar os departamentos (especialidades) no Rocket.chat que o contrato permite
3) Buscar os agentes (epsecialistas) disponíveis nos departamentos (especialidades) permitidas
4) Exibir a relação dos especilistas disponíveis: Especialidade, Nome

O contratante chama o especialista nesta tela.

Usar [[APIs]] do [[Rocket.chat]] e sistema 2headeddoctor [[conceito]]

> [!BUG] > Para resolver. 

O cliente abre um chat para acionar um especilista mas provalemente a conversa será sobre vários pacientes. É preciso identifcar o paciente para que o sistema grave as informações atreladas ao paciente correto.
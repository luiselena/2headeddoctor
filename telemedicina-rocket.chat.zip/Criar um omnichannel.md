
Servidor onde o rocketchat está instalado
https://rocket.2headed.xyz

user: luiselena
pass: lulues
email: lulues@gmail.com

Seguindo os passos:
https://docs.rocket.chat/guides/omnichannel


Configurações Importantes

Menu Administração - Ominichannel
Roteamento : Autoseleção
Chamadas de Vídeo e Audio: JITSI

Menu Administração - Video Conferência
habilitar JITSI


- horário de expediente
- departamentos
- gerentes
- agentes


É possível importar usuários de um arquivo .csv

Menu Administração - Importar
The `users.csv` is a file that contains the user details, each line containing a new user, and the user details are:

1.  1. Username (must not contain @ and some other special characters)
2.  2. Email    
3.  3. Name
    
bradley.hilton,bradley.hilton@example.com,Bradley Hilton
billy.bob, billy.bob@example.com, Billy Bob Jr.
graywolf336,graywolf336@example.com,GrayWolf336

***
É preciso ter um [[Live Chat]] para usar o Omnichannel configurado. 

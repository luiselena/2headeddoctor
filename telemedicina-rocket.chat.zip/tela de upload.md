## Tela de Upload
O sistema permiitrá uploads de arquivos com as extensões:
- PDF
- JPG
- PNG
- DCM

**É preciso configurar no Rocket.chat as extensões permiitdas para upload**

O médico contratante pode fazer upload pelo sistema ou pelo celular.

Para usar o celular para enviar uma foto, por exemplo, o médico deverá ler o QRCODE que será exibido na tela do sistema e com esse QRCODE direcionará para uma página no celular od médico onde ele poderá fazer upload.

Esses arquivos deverão ser registrados em uma base de dados do 2headeddoctor.


*exemplo de como fazer upload de aplicação .net para o rocket.chat*
https://stackoverflow.com/questions/57191015/how-to-upload-files-from-a-net-application-to-a-rocket-chat-channel

## Endpoints do Rocket.chat


> [!INFO] > Links importantes. 

Omnichannel Endpoints
https://developer.rocket.chat/reference/api/rest-api/endpoints/omnichannel/omnichannel-endpoints


*exemplo de como fazer upload numa aplicação .net para o rocket.chat*
https://stackoverflow.com/questions/57191015/how-to-upload-files-from-a-net-application-to-a-rocket-chat-channel


Documentação de APIs REST
https://developer.rocket.chat/reference/api/rest-api

Livechat Endpoints [[Live Chat]]
https://developer.rocket.chat/reference/api/rest-api/endpoints/omnichannel/livechat-endpoints


Integrando meu sistema com o Rocket.Chat
https://blog.4linux.com.br/integrando-seu-chat-com-o-rocket-omnichannel/

https://www.youtube.com/watch?v=7Qd1OpRlJso



Verificar [[Mapeamento de APIs]] para seguir o passo a passo de integração.


> [!WARNING] > API só funciona se o Rocket estiver com HTTPS.